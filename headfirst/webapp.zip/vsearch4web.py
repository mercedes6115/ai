
from flask import Flask, redirect, render_template, request
from vsearch import search4letters
app = Flask(__name__)

# 데코레이터 decorator 장식자

@app.route('/') # 사이트 접근 주소 

def hello() -> '302':
    return redirect('/entry')
# 전달 방식
@app.route('/search4',methods=['POST']) 
def do_search() -> 'html':
    phrase = request.form['phrase']
    letters = request.form['letters']
    title = '찾은 결과 입니다'
    return render_template('result.html',
                           the_phrase = phrase,
                           the_letters= letters,
                           the_title = title,
                           the_results = results
                           )

    
@app.route('/entry')
def entry_page() -> 'html':
    return render_template('entry.html',
                           the_title='글자 찾기 사이트에 방문하신걸 환영합니다 ')
    
app.run()